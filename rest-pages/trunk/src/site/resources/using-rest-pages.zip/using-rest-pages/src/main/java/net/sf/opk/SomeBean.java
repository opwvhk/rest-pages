package net.sf.opk;

public class SomeBean
{
	private String name;
	private SomeBean parent;
	private int favoriteNumber;


	public String getName()
	{
		return name;
	}


	public void setName(String name)
	{
		this.name = name;
	}


	public SomeBean getParent()
	{
		return parent;
	}


	public void setParent(SomeBean parent)
	{
		this.parent = parent;
	}


	public int getFavoriteNumber()
	{
		return favoriteNumber;
	}


	public void setFavoriteNumber(int favoriteNumber)
	{
		this.favoriteNumber = favoriteNumber;
	}


	@Override
	public String toString()
	{
		final StringBuilder sb = new StringBuilder();
		sb.append("SomeBean");
		sb.append("{name='").append(name).append('\'');
		sb.append(", favoriteNumber=").append(favoriteNumber);
		sb.append(", parent=").append(parent);
		sb.append('}');
		return sb.toString();
	}
}
