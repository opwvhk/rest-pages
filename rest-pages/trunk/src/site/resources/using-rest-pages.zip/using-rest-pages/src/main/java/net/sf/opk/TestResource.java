package net.sf.opk;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import net.sf.opk.rest.forms.HTMLForm;
import net.sf.opk.rest.pages.ResourceForward;


@Path("test")
public class TestResource
{
	@GET
	public ResourceForward read()
	{
		return new ResourceForward("/WEB-INF/test.jsp");
	}


	@POST
	public ResourceForward read(HTMLForm htmlForm)
	{
		SomeBean bean = new SomeBean();
		SomeBean parentBean = new SomeBean();
		bean.setParent(parentBean);

		htmlForm.applyValuesTo("bean", bean);

		ResourceForward forward = new ResourceForward("/WEB-INF/test.jsp");
		return forward.withAttribute("submitted", htmlForm.toString()).withAttribute("bean", bean.toString());
	}
}

